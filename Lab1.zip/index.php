<?php
include 'conexion.php';
$sql = "SELECT * FROM productos";
$resultado = $conexion->query($sql);
if ($resultado->num_rows > 0) {
while ($fila = $resultado->fetch_assoc()) {
echo "ID: " . $fila["id"] . " - Nombre: " . $fila["nombre"] . " - Precio: "
. $fila["precio"] . "<br>";
}
} else {
echo "No hay productos registrados.";
}
$conexion->close();
?>